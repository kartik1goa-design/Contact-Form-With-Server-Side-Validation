const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = 3000;

// Middleware configuration
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// MySQL Connection Setup
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',      // Replace with your MySQL username
    password: 'kartik',      // Replace with your MySQL password
    database: 'contact_db'
});

db.connect((err) => {
    if (err) {
        console.error('Database connection failed:', err.stack);
        return;
    }
    console.log('Connected to MySQL database (contact_db).');
});

// Route: Handle contact form submission
app.post('/submit-contact', (req, res) => {
    const { full_name, email, subject, message } = req.body;

    const sql = `INSERT INTO contact_form (full_name, email, subject, message) VALUES (?, ?, ?, ?)`;

    db.query(sql, [full_name, email, subject, message], (err, result) => {
        if (err) {
            console.error('Error inserting message:', err);
            return res.status(500).send('Failed to save message: ' + err.message);
        }
        res.send('<h1>Contact form submitted successfully!</h1><a href="/">Send another message</a>');
    });
});

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});